/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_array;

/**
 *
 * @author asmaa
 */
public class Test_array {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[]aa={1,2,3};
        
        System.out.println(aa[0]);
        System.out.println("print sum");
//                System.out.println(aa[0]+aa[2]);
//
//           
//        String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
//for (String i : cars) {
//  System.out.println(i);
//}
//int [] arr = {10,20,30};
//for (int i = 0; i < arr.length; i++) {
//  System.out.println(cars[i]);
//}
//
// int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
//    for (int i = 0; i < myNumbers.length; ++i) {
//      for(int j = 0; j < myNumbers[i].length; ++j) {
//        System.out.println(myNumbers[i][j]);
//    }
//    
//}
    }


}