/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test_linkedlist;
import java.util.*;

/**
 *
 * @author asmaa
 */
public class Test_linkedlist {

  
    public static void main(String[] args) {
  LinkedList<String> cars = new LinkedList<String>();
    cars.add("Volvo");
    cars.add("BMW");
    cars.add("Ford");
    cars.add("Mazda");
    cars.set(2,"fff");
    System.out.println(cars);
   
//     System.out.println("after add first");
//    System.out.println(cars);
//     cars.addLast("bbb");
//     System.out.println("after add last");
//    System.out.println(cars);
//    cars.removeFirst();
//     System.out.println("after remove first");
//    System.out.println(cars);
//     System.out.println(cars.getFirst());
//     System.out.println(cars.size());
//     
//     ///////////////////////////////
//      LinkedList list = new LinkedList(); 
//	  list.add(new Integer(10)); 
//	  list.add(new Integer(20));
//	  list.add(new Integer(30)); 
//          list.add("fff");
//              System.out.println(list);
//
//         System.out.println("print integer list ");
//	  for(int i=0; i<list.size(); i++) 
//		{ 
//		Object temp = list.get(i); 
//                System.out.println(temp); 
//		} 
//          
//      System.out.println("------------------------"); 
//
//	for(int i=list.size()-1; i>=0; i--) 
//		{ Object temp = list.get(i);
//	 	System.out.println(temp); 
//		} 
    	} 

     
     
    }
    

